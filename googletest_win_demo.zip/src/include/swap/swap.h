#ifndef __SWAP_H_
#define __SWAP_H_


void swap(int &a, int &b);

#endif // !__SWAP_H_